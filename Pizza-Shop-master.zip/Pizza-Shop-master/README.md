



## Demo Website
👉 Live Demo :https://piza-delivery-shop.herokuapp.com/

## Run Locally 🚀

- git clone git@github.com/AbdulWahab0/Pizza-Shop.git
- cd Piz-Shop
- Run Backend
  - npm install
  - npm start
- Run Frontend
  - open new terminal
  - cd frontend
  - npm install
  - npm start

Let me know if you have any questions. [Email Abdul Wahab ](mailto:wahab3060h@gmail.com)

